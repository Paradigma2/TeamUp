<?php $__env->startSection('link1'); ?>
	<a class="nav-link"  href="#">Lobi</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link2'); ?>
	<a class="nav-link"  href="#">Nađi saigrača</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link3'); ?>
	<a class="nav-link"  href="#">Članci</a>
<?php $__env->stopSection(); ?>





<?php $__env->startSection('link5'); ?>
	<div class="dropdown ">

	 	<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Nick
      </a>
      <div class="dropdown-menu">

        <a class="dropdown-item" href="#">Profil</a>
        <a class="dropdown-item" href="#">Inbox</a>
        <a class="dropdown-item" href="#">Log out</a>

      
       
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('navbar/navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>