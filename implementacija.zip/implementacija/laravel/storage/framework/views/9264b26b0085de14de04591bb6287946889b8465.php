	
<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/styleProfile.css')); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('navbar'); ?>


	<?php echo $__env->make('navbar/navbarUser', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>




<?php $__env->startSection('editProfilePicture'); ?>

	
		Promeni sliku
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('promeniLozinku'); ?>
	<button  class="button" >Promeni lozinku</button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('kreirajOglas'); ?>
	<button  class="button"><a class="clearFormat" href="/createEditAdForm">Kreiraj oglas</a></button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('obrisiNalog'); ?>
	<button  class="button" type="button" > Obriši nalog </button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("editDescription"); ?>
	<i class="material-icons" style="cursor:pointer;">create</i>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection("icon11"); ?>
	<i class="material-icons" style="cursor:pointer;">create</i>	
<?php $__env->stopSection(); ?>
<?php $__env->startSection("icon12"); ?>
	<i class="material-icons" style="cursor:pointer;">delete</i>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection("icon21"); ?>
	<i class="material-icons" style="cursor:pointer;">create</i>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection("icon22"); ?>
	<i class="material-icons" style="cursor:pointer;">delete</i>	
<?php $__env->stopSection(); ?>


<?php $__env->startSection("icon31"); ?>
	<i class="material-icons" style="cursor:pointer;">create</i>	
<?php $__env->stopSection(); ?>




<?php $__env->startSection("icon32"); ?>
	<i class="material-icons" style="cursor:pointer;">delete</i>	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile/profile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>