	
<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/styleInbox.css')); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('navbar'); ?>


	<?php echo $__env->make('navbar/navbarAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('inbox/inbox', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>