<?php $__env->startSection('link1'); ?>
	<a class="nav-link"  href="#">Lobi</a>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('link2'); ?>
	<a class="nav-link"  href="#">Nađi saigrača</a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('link5'); ?>
	 



<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar/navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>