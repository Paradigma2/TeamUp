	
<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/styleProfile.css')); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('navbar'); ?>


	<?php echo $__env->make('navbar/navbarUser', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('grade'); ?>
	<button class="mt-2 mb-2 buttonGrade btn-block" >
		Oceni korisnika
	</button>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('blokiraj'); ?>
	<button  class="button" href="">Blokiraj</button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('zaprati'); ?>
	<button  class="button" href="">Zaprati</button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('posaljiPorukuAdmin'); ?>
	<button id="obrisi" class="button" href="">Pošalji poruku</button>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile/profile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>