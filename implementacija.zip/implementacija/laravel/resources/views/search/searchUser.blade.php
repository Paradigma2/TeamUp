@extends('search/search')

@section('navbar')
	@include('navbar/navbarUser')
@endsection