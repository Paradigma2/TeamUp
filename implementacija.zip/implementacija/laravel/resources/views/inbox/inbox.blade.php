@extends('main')
@section('styles')
	<link rel="icon" href="slike/icon.png" type="image/png">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

@endsection
@section('content')
<script>

	</script>
		<div class="container-fluid" style="min-height: 100%;">
		<div class="row mt-3">
			<div class="col-sm-3"  style=" background-color: rgba(5,5,5,0.4);">
				<button id="collapseButton"  class="btn-block btn buttonGrade mt-2 mb-2 " style="border-radius: 5px;"type="button" data-toggle="collapse" data-target="#collapseInbox" class="visible-xs visible-sm collapsed">Prikazi ćaskanja</button>
				<div  class="collapse" id="collapseInbox" style="  overflow-x: hidden; overflow-y:scroll;height:560px;"	 >

  <!-- KAKO DA NAPRAVIM OVO SRANJE DESNO DA IMA SKROL ALI DA NEMA PIKSELE >,<-->


			
					<div  class=" message row ">
							<div class="col-sm-12 mb-2">
								<img src="slike/icon2.jpg" width="30px">
								<label style="color: white;">
									Zyra
								</label>
							</div>
							<div class="col-sm-12">
							<textarea readonly style="overflow:hidden" class="form-control " style="min-width: 100%" >Sed ultricies, nunc a vulputate faucibus, tellus est dignissim ante, in vestibulum nisl dui id dolor. Aliquam erat volutpat. Donec at leo at velit facilisis fringilla. In ornare ullamcorper urna at tincidunt. Mauris ac pretium tortor, at lacinia tellus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
							</textarea>
							</div>
					
					</div>
					<div class=" message row ">
							<div class="col-sm-12 mb-2">
								<img src="slike/icon2.jpg" width="30px">
								<label style="color: white;">
									Zyra
								</label>
							</div>
							<div class="col-sm-12">
							<textarea readonly style="overflow:hidden" class="form-control " style="min-width: 100%" >Sed ultricies, nunc a vulputate faucibus, tellus est dignissim ante, in vestibulum nisl dui id dolor. Aliquam erat volutpat. Donec at leo at velit facilisis fringilla. In ornare ullamcorper urna at tincidunt. Mauris ac pretium tortor, at lacinia tellus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
							</textarea>
							</div>
					
					</div>
					<div border="1px" class=" message row ">
							<div class="col-sm-12 mb-2">
								<img src="slike/icon2.jpg" width="30px">
								<label style="color: white;">
									Zyra
								</label>
							</div>
							<div class="col-sm-12">
							<textarea readonly style="overflow:hidden" class="form-control " style="min-width: 100%" >Sed ultricies, nunc a vulputate faucibus, tellus est dignissim ante, in vestibulum nisl dui id dolor. Aliquam erat volutpat. Donec at leo at velit facilisis fringilla. In ornare ullamcorper urna at tincidunt. Mauris ac pretium tortor, at lacinia tellus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
							</textarea>
							</div>
					
					</div>
					<div class=" message row ">
							<div class="col-sm-12 mb-2">
								<img src="slike/icon2.jpg" width="30px">
								<label style="color: white;">
									Zyra
								</label>
							</div>
							<div class="col-sm-12">
							<textarea readonly style="overflow:hidden" class="form-control " style="min-width: 100%" >Sed ultricies, nunc a vulputate faucibus, tellus est dignissim ante, in vestibulum nisl dui id dolor. Aliquam erat volutpat. Donec at leo at velit facilisis fringilla. In ornare ullamcorper urna at tincidunt. Mauris ac pretium tortor, at lacinia tellus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
							</textarea>
							</div>
					
					</div>
					<div  class=" message row ">
							<div class="col-sm-12 mb-2">
								<img src="slike/icon2.jpg" width="30px">
								<label style="color: white;">
									Zyra
								</label>
							</div>
							<div class="col-sm-12">
							<textarea readonly style="overflow:hidden" class="form-control " style="min-width: 100%" >Sed ultricies, nunc a vulputate faucibus, tellus est dignissim ante, in vestibulum nisl dui id dolor. Aliquam erat volutpat. Donec at leo at velit facilisis fringilla. In ornare ullamcorper urna at tincidunt. Mauris ac pretium tortor, at lacinia tellus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
							</textarea>
							</div>
					
					</div>
					<div  class=" message row ">
							<div class="col-sm-12 mb-2">
								<img src="slike/icon2.jpg" width="30px">
								<label style="color: white;">
									Zyra
								</label>
							</div>
							<div class="col-sm-12">
							<textarea readonly style="overflow:hidden" class="form-control " style="min-width: 100%" >Sed ultricies, nunc a vulputate faucibus, tellus est dignissim ante, in vestibulum nisl dui id dolor. Aliquam erat volutpat. Donec at leo at velit facilisis fringilla. In ornare ullamcorper urna at tincidunt. Mauris ac pretium tortor, at lacinia tellus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
							</textarea>
							</div>
					
					</div>
					<div  class=" message row ">
							<div class="col-sm-12 mb-2">
								<img src="slike/icon2.jpg" width="30px">
								<label style="color: white;">
									Zyra
								</label>
							</div>
							<div class="col-sm-12">
							<textarea readonly style="overflow:hidden" class="form-control " style="min-width: 100%" >Sed ultricies, nunc a vulputate faucibus, tellus est dignissim ante, in vestibulum nisl dui id dolor. Aliquam erat volutpat. Donec at leo at velit facilisis fringilla. In ornare ullamcorper urna at tincidunt. Mauris ac pretium tortor, at lacinia tellus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
							</textarea>
							</div>
					
					</div>
					<div  class=" message row ">
							<div class="col-sm-12 mb-2">
								<img src="slike/icon2.jpg" width="30px">
								<label style="color: white;">
									Zyra
								</label>
							</div>
							<div class="col-sm-12">
							<textarea readonly style="overflow:hidden" class="form-control " style="min-width: 100%" >Sed ultricies, nunc a vulputate faucibus, tellus est dignissim ante, in vestibulum nisl dui id dolor. Aliquam erat volutpat. Donec at leo at velit facilisis fringilla. In ornare ullamcorper urna at tincidunt. Mauris ac pretium tortor, at lacinia tellus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
							</textarea>
							</div>
					
					</div>
				
				</div>
			</div>


			<div class="col-sm-9  " style="background-color: rgba(5,5,5,0.4);">
				<div class="row ">
					<div id="messages" style="  overflow-x: hidden; overflow-y:scroll; height:460px;"	>
					<div  class="  col-sm-6 ml-auto mt-3" style="padding:10px;  background-color: rgba(5,5,5,0.8);  border-radius: 15px;">
							<div class="col-sm-12 mb-2">
								<img src="slike/icon2.jpg" width="30px">
								<label style="color: white;">
									Zyra
								</label>
							</div>
							<div class="col-sm-12" >
							<label style="color:white;">Sed ultricies, nunc a vulputate faucibus, tellus est dignissim ante, in vestibulum nisl dui id dolor. Aliquam erat volutpat. Donec at leo at velit facilisis fringilla. In ornare ullamcorper urna at tincidunt. Mauris ac pretium tortor, at lacinia tellus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
							</label>
							</div>
					
					</div>

					<div  class="  col-sm-6  mt-3" style="padding:10px;  background-color: rgba(5,5,5,0.8);  border-radius: 15px;">
							<div class="col-sm-12 mb-2">
								<img src="slike/icon2.jpg" width="30px">
								<label style="color: white;">
									Zyra
								</label>
							</div>
							<div class="col-sm-12" >
							<label style="color:white;">Lorem ipsum dolor sit amet, consectetur adipiscing elit.
							</label>
							</div>
					
					</div>

					<div  class="  col-sm-6 ml-auto mt-3" style="padding:10px;  background-color: rgba(5,5,5,0.8);  border-radius: 15px;">
							<div class="col-sm-12 mb-2">
								<img src="slike/icon2.jpg" width="30px">
								<label style="color: white;">
									Zyra
								</label>
							</div>
							<div class="col-sm-12" >
							<label style="color:white;">Sed ultricies, nunc a vulputate faucibus, tellus est tortor, at lacinia tellus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
							</label>
							</div>
					
					</div>

					<div  class="  col-sm-6  mt-3" style="padding:10px;  background-color: rgba(5,5,5,0.8);  border-radius: 15px;">
							<div class="col-sm-12 mb-2">
								<img src="slike/icon2.jpg" width="30px">
								<label style="color: white;">
									Zyra
								</label>
							</div>
							<div class="col-sm-12" >
							<label style="color:white;">Sed ultricies, nunc a vulputate faucibus, tellus est dignissim ante, in vestibulum nisl dui id dolor. Aliquam erat volutpat. Donec at 
							</label>
							</div>
					
					</div>


					<div  class="  col-sm-6 ml-auto mt-3" style="padding:10px;  background-color: rgba(5,5,5,0.8);  border-radius: 15px;">
							<div class="col-sm-12 mb-2">
								<img src="slike/icon2.jpg" width="30px">
								<label style="color: white;">
									Zyra
								</label>
							</div>
							<div class="col-sm-12" >
							<label style="color:white;">Sed ultricies, nunc a vulputate faucibus, tellus est dignissim ante, in vestibulum nisl dui id dolor. Aliquam erat volutpat. Donec at leo at velit facilisis fringilla. In ornare ullamcorper urna at tincidunt. Mauris ac pretium tortor, at lacinia tellus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
							</label>
							</div>
					
					</div>



				</div>
				<div class="mt-2"style="width: 100%;">
					<textarea class="form-control"  placeholder="Napisite poruku..." cols="115" ></textarea>
					
					
					
						<button class="btn-block mt-2 buttonGrade" >
							Posalji
						</button>
				</div>
				</div>
			</div>
		</div>
	</div>

	<script>
	var objDiv = document.getElementById("messages");
objDiv.scrollTop = objDiv.scrollHeight;
		
	</script>
@endsection