@extends('navbar/navbar')

@section('link1')
	<a class="nav-link" href="#">Lobi</a>
@endsection


@section('link4')
	<a class="nav-link"  href="#">Register</a>
@endsection

@section('link5')
	<a class="nav-link"  href="#">Login</a>
@endsection
