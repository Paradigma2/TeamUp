<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Champion - klasa za pristup tabeli champion u bazi podataka
 *
 * @version 1.0
 */

class Champion extends Model
{
    protected $table='champion';
}
