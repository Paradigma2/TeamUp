<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Mode - klasa za pristup tabeli mode u bazi podataka
 *
 * @version 1.0
 */

class Mode extends Model
{

    protected $table='mode';

}
