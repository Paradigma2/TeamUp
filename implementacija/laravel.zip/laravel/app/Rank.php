<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Rank - klasa za pristup tabeli rank u bazi podataka
 *
 * @version 1.0
 */

class Rank extends Model
{
    protected $table='rank';
}
