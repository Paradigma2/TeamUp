<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Position - klasa za pristup tabeli position u bazi podataka
 *
 * @version 1.0
 */

class Position extends Model
{

    protected $table='position';

}
