<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mastery extends Model
{
    protected $table='mastery';
}
