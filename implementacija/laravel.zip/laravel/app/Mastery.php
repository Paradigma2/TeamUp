<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Mastery - klasa za pristup tabeli mastery u bazi podataka
 *
 * @version 1.0
 */

class Mastery extends Model
{
    protected $table='mastery';
}
