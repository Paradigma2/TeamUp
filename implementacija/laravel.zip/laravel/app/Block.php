<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Block - klasa za pristup tabeli block u bazi podataka
 *
 * @version 1.0
 */

class Block extends Model
{
    protected $table='block';
}
