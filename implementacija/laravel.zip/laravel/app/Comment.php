<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Comment - klasa za pristup tabeli comment u bazi podataka
 *
 * @version 1.0
 */

class Comment extends Model
{
    protected $table='comment';
}
