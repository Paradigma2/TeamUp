<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Article - klasa za pristup tabeli article u bazi podataka
 *
 * @version 1.0
 */

class Ban extends Model
{
    protected $table='ban';
}
