<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Article - klasa za pristup tabeli article u bazi podataka
 *
 * @version 1.0
 */

class Article extends Model
{
    protected $table='article';
}
