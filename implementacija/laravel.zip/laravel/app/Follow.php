<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Follow - klasa za pristup tabeli follow u bazi podataka
 *
 * @version 1.0
 */

class Follow extends Model
{
    protected $table='follow';
}
