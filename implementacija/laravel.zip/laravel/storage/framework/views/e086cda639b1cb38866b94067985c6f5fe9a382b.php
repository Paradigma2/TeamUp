	
<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/styleProfile.css')); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('navbar'); ?>


	<?php echo $__env->make('navbar/navbarAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>




<?php $__env->startSection('udaljiSaSajta'); ?>
	<button  class="button" href="">Udalji sa sajta</button>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('unapredi'); ?>
	<?php if($isMod==0): ?>
	<button class="button" href="">Postavi mod</button>
	<?php else: ?>
	<button  class="button" href="">Ukloni mod</button>
<?php endif; ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('posaljiPorukuAdmin'); ?>
	<button  class="button" href="">Pošalji poruku</button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("btnSidebar1"); ?>
		<i class="material-icons" style="cursor:pointer;">delete</i>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("btnSidebar2"); ?>
		<i class="material-icons" style="cursor:pointer;">delete</i>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("icon12"); ?>
	<i class="material-icons" style="cursor:pointer;">delete</i>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("icon22"); ?>
	<i class="material-icons" style="cursor:pointer;">delete</i>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("icon32"); ?>
	<i class="material-icons" style="cursor:pointer;">delete</i>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('profile/profile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>