<!--autor: Jana Kragovic 23/2015-->




<?php $__env->startSection('link1'); ?>
	<a class="nav-link"  href="/home">Lobi</a>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('link2'); ?>
	<a class="nav-link"  href="/search">Nađi saigrača</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link4'); ?>
 <div style="margin-top: 10px; "> 

<a class="bla" href="inbox"><i  id="sanduce" class="material-icons">&#xe625;</i></a>
 </div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link5'); ?>
	 
<div class="dropdown ">

	 	<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        <?php echo e(Auth::user()->username); ?>

      </a>
      <div class="dropdown-menu">

              <a class="dropdown-item" href="showUser">Profil</a> 
        <a class="dropdown-item" href="inbox">Inbox</a>
        <a class="dropdown-item" href="/logOut" onclick="prekini()">Log out</a>

      
       
    </div>


<?php $__env->stopSection(); ?>

<script>
  var timerID;
    function proveri(){

      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function(){
        if(this.status==200 && this.readyState==4){
          if(this.responseText == "nova"){
         document.getElementById("sanduce").innerHTML="&#xe85a";
               document.getElementById("sanduce").style.color="red";
          
          }else{
             document.getElementById("sanduce").innerHTML="&#xe625";
          }
        }
      }

      xmlhttp.open("GET", "novaporuka", true);
      xmlhttp.send();
      timerID  = setTimeout("proveri()", 5000);
    }
    function prekini(){
      if(timerID) {
         clearTimeout(timerID);   
         timerID  = 0;
     }
    }
</script>
<?php echo $__env->make('navbar/navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>