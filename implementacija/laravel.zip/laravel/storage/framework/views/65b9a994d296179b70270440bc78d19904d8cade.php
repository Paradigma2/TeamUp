<!--autor: Jana Kragovic 23/2015-->


<?php $__env->startSection('link1'); ?>
	<a class="nav-link"  href="/home">Lobi</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link2'); ?>
	<a class="nav-link"  href="/search">Nađi saigrača</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link3'); ?>
	<a class="nav-link"  href="/articles">Članci</a>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('link4'); ?>

<a href="" id="inboxlink"><i class="material-icons">chat</i></a>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('link5'); ?>
	<div class="dropdown ">

	 	<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        <?php echo e(Auth::user()->username); ?>

      </a>
      <div class="dropdown-menu">

        <a class="dropdown-item" href="showUser">Profil</a>
        
        <a class="dropdown-item" href="inbox">Inbox</a>
        <a class="dropdown-item" href="/logOut">Log out</a>

      
       
    </div>


<?php $__env->stopSection(); ?>

<script>
    function proveri(){
       alert("cao");
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function(){
        if(this.status==200 && this.readyState==4){
          if(this.responseText == "nova"){

            document.getElementById("inboxlink").innerHTML="ima";
          }
        }
      }

      xmlhttp.open("GET", "novaporuka", true);
      xmlhttp.send();
    }
</script>
<?php echo $__env->make('navbar/navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>