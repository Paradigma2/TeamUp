<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/stylearticles.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>

	<?php echo $__env->make('navbar/navbarModerator', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container article mt-3">

		<?php if(Session::has('errors')): ?>
<div class="row mt-3">
	
	<div class="col-sm-12 mt-3">
			 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      			 <div class="alert alert-primary" style="text-align: center;">
				<?php echo e($error); ?>

				</div>
   			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		
		<?php endif; ?>
		<div class="row">
			<div class="col-sm-12">

				<?php if($type == 'create'): ?>
				<form class="m-5" action="makeArticle" method="post">
				<?php else: ?>
				<form class="m-5" action="updateArticle" method="post">
					<input type="hidden" name="articleId" value="<?php echo e($article->id); ?>">
				<?php endif; ?>

					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4 d-flex justify-content-center">
								<h4><label for="naslov">Naslov:</label></h4>
							</div>
							<div class="col-sm-8">
								<?php if($type=='create'): ?>
								 <input type="text" class="form-control" id="naslov" name="naslov">
								 <?php else: ?>
								 <input type="text" class="form-control" id="naslov" name="naslov" value="<?php echo e($article->headline); ?>">
								 <?php endif; ?>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4 d-flex justify-content-center">
								<h4><label for="tekst">Tekst:</label></h4>
							</div>
							<div class="col-sm-8">
								<textarea name="tekst" id="tekst" class="form-control" rows="13">
									<?php if($type=='edit'): ?>
									<?php echo e($article->content); ?>

									<?php endif; ?>
								</textarea>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-4">
							<div class="row">
								<div class="col-sm-6">
									 <button type="button" class="btn btn-primary"><a class="nav-link" href=/articles style="color:white;">Odustani</a></button>
								</div>
								<div class="col-sm-6">
									 <button type="button" class="btn btn-primary"><a class="nav-link" href="#" style="color:white;">Ubaci sliku</a></button>
								</div>
							</div>
							
							
						</div>
						<div class="col-sm-8">
							 <button type="submit" name="bt" class="btn btn-primary nav-link" style="width:100%;">Objavi</button>
						</div>
				
					</div>
					   
				</form>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>