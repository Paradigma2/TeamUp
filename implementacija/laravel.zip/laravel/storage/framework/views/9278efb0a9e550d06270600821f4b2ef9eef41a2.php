<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/stylearticles.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>

	<?php echo $__env->make('navbar/navbarModerator', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-sm-8 mt-3 tab-content">
			<?php if($length>0): ?>
			<label hidden><?php echo e($l = $length); ?></label>
			<?php for($j=0, $page=0; $j<$l; $page++): ?>
			 
			<?php if($j==0): ?>
				<div class="tab-pane active" id="page<?php echo e($page + 1); ?>">
			<?php else: ?>
				<div class="tab-pane fade" id="page<?php echo e($page + 1); ?>">
			<?php endif; ?>
			
				<?php for($i=0; $i<3 && $j<$l; $i++, $j++): ?>

				<div class="row">
					<div class="col-sm-12">
						<div class="card mt-2 article">
							
							<div class="card-body">
								<div class="row">
									<div class="col-sm-10">
										<h4 class="card-title headline mt-1" >
											<label align="center"><?php echo e($articles[$j]->headline); ?></label>
										</h4>
									</div>
									<div class="col-sm-1">
										<a data-toggle="modal" href="#deleteModal<?php echo e($articles[$j]->id); ?>">
											<i class="material-icons" style="cursor:pointer;">delete</i>
										</a>
										
									</div>
									<div class="col-sm-1">
										<a href="/editArticle?id=<?php echo e($articles[$j]->id); ?>">
											<i class="material-icons" style="cursor:pointer;">create</i>
										</a>
									</div>
								</div>
								<?php
									$content = $articles[$j]->content;
									$splitContent = explode(PHP_EOL, $content);
								?>
								<p class="card-text"><?php echo e($splitContent[0]); ?></p>


								<div class="card-text collapse" id="collapseArticle<?php echo e($articles[$j]->id); ?>">
									<?php $__currentLoopData = $splitContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($c != $splitContent[0]): ?>
										<p><?php echo e($c); ?></p>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
								<a data-toggle="collapse" href="#collapseArticle<?php echo e($articles[$j]->id); ?>" onclick="proba('klik<?php echo e($articles[$j]->id); ?>')" >
									<i class="material-icons" > <label style="cursor:pointer;" id="klik<?php echo e($articles[$j]->id); ?>">expand_more</label></i>
								</a>
							</div>
						</div>
					</div>
				</div>

				<?php endfor; ?>
			</div>
			<?php endfor; ?>
			
					<ul class="pagination nav nav-pills mt-3 d-flex justify-content-center">

						
						<?php for($i=0; $i<$page; $i++): ?>
						
						<li class="page-item"><a class="page-link" data-toggle="pill" href="#page<?php echo e($i + 1); ?>"><?php echo e($i + 1); ?></a></li>
						
						<?php endfor; ?>
					</ul>
				<?php else: ?>
				<div class="container article mt-3">
				<div class="row">
					<div class="col-sm-12">
						<form class="m-5" action="makeArticle" method="post">
							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
							<div class="form-group">
								<div class="row">
									<div class="col-sm-4 d-flex justify-content-center">
										<h4><label for="naslov">Naslov:</label></h4>
									</div>
									<div class="col-sm-8">
										 <input type="text" class="form-control" id="naslov" name="naslov">
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-sm-4 d-flex justify-content-center">
										<h4><label for="tekst">Tekst:</label></h4>
									</div>
									<div class="col-sm-8">
										<textarea name="tekst" id="tekst" class="form-control" rows="13"></textarea>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-4">
									<div class="row">
										<div class="col-sm-6">
											 <button type="button" class="btn btn-primary"><a class="nav-link" href="#" style="color:white;">Ubaci sliku</a></button>
										</div>
									</div>
									
									
								</div>
								<div class="col-sm-8">
									 <button type="submit" name="bt" class="btn btn-primary nav-link" style="width:100%;">Objavi</button>
								</div>
						
							</div>
							   
						</form>
					</div>
				</div>
				</div>
				<?php endif; ?>
				</div>
				
		
		<div class="col-sm-4">
			<div class="row mt-3">
				<div class="col-sm-12">
					<button type="button" class="btn btn-primary" style="width:100%;"><a class="nav-link" href=/createArticle style="color:white;">Kreiraj clanak</a></button>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">
			<div class="card mt-3 article">
				<div class="card-body">
					<div class="card-title">
						<h2>Pravila</h2>
						
					</div>
					<p>Moderator ne sme davati svoj profil drugim igracima na koriscenje. U suprotnom, moderator ce biti banovan sa sajta.</p>
				<p>Clanci moraju biti vezani za desavanja u LoL-u i sadrzati korisne i zanimljive informacije. U suprotnom, clanci ce biti uklonjeni sa sajta.</p>
				<p>Clanci ne smeju imati vulgaran sadrzaj. U suprotnom, moderator ce biti banovan, a svi njegovi clanci uklonjeni sa sajta.</p>
				<p>Clanci ne smeju sluziti za prozivanje drugih igraca ili korisnika sajta. U suprotnom, moderator ce biti banovan, a svi njegovi clanci uklonjeni sa sajta.</p>
				</div>
				
			</div>
		</div>
	</div>
		</div>
		</div>
	</div>
	<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="modal fade" id="deleteModal<?php echo e($article->id); ?>">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content pages">

	      <!-- Modal Header -->
	      <div class="modal-header ">
	        <h4 class="modal-title d-flex justify-content-center">Da li ste sigurni?</h4>
	        <button type="button" class="close" style="color:white;" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      

	      <!-- Modal footer -->
	      <div class="modal-body">
	      	<div class="row">
	      		<div class="col-sm-12  d-flex justify-content-center">
	      			<form name="deleteArticle" action="deleteArticle" method="POST">
	      				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	      				<input type="hidden" name="id" value="<?php echo e($article->id); ?>">
	      			<button type="submit" class="btn btn-primary mr-2" >Potvrdi</button>
	      			</form>
	      			<button type="button" class="btn btn-primary" data-dismiss="modal">Odustani</button>
	      		</div>
	      		
	      	</div>
	        
	        
	      </div>

	    </div>
	  </div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>

	<script language="javascript">
		function proba(klik){
			labela = document.getElementById(klik);
			if(labela.innerHTML == "expand_more"){
				labela.innerHTML="expand_less"
			}
			else{
				labela.innerHTML="expand_more"
			}
		}
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>