<?php $__env->startSection('link1'); ?>
	<a class="nav-link"  href="/home">Lobi</a>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('link2'); ?>
	<a class="nav-link"  href="/search">Nađi saigrača</a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('link5'); ?>
	 
<div class="dropdown ">

	 	<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        <?php echo e(Auth::user()->username); ?>

      </a>
      <div class="dropdown-menu">

              <a class="dropdown-item" href="showUser">Profil</a> 
        <a class="dropdown-item" href="#">Inbox</a>
        <a class="dropdown-item" href="/logOut">Log out</a>

      
       
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar/navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>