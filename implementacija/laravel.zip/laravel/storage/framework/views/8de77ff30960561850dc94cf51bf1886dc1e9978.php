<?php $__env->startSection('link1'); ?>
	<a href="#">Lobi</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link2'); ?>
	<a href="#">Pretraga igrača</a>
<?php $__env->stopSection(); ?>






<?php $__env->startSection('link5'); ?>
	 <div class="dropdown fright">
   		<a href="javascrip:void(0)" class="dropbtn">Nick</a>
    	<div class="dropdown-content">
  		    <a href="lobby_gost.html">Log out</a>
		</div>
 	 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>