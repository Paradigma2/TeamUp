<?php $__env->startSection('link1'); ?>
	<a class="nav-link" href="/guestLobby">Lobi</a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('link4'); ?>
	<a class="nav-link"  href="/registerForm">Register</a>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link5'); ?>
	<a class="nav-link"  href="#logInModal" data-toggle='modal'>Log In</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('navbar/navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>