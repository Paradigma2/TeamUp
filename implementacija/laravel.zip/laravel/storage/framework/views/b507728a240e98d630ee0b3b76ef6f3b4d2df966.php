<?php $__env->startSection('styles'); ?>
	<link rel="icon" href="slike/icon.png" type="image/png">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo e(URL::asset('css/styleProfile.css')); ?>">
<?php $__env->stopSection(); ?>


<?php if(Session::get('msgBlocked')!=null): ?>

<div class="alert alert-primary alert-dismissible fade show" role="alert">
  <strong style="color:black;"><?php echo e(Session::get('msgBlocked')); ?></strong> 
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>


<?php if(Session::get('msgComment')!=null): ?>

<div class="alert alert-primary alert-dismissible fade show" role="alert">
  <strong style="color:black;"><?php echo e(Session::get('msgComment')); ?></strong> 
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>
<?php $__env->startSection('content'); ?>

	<div class="row mt-3"  style="background-color: rgba(5,5,5,0.8); color:white;">
		<div class="col-sm-2 " >
			<div class="profilePicture m-4" width="185px">
				<img class="blur" border="2px" src="<?php echo e($profilePic); ?>"alt="Profilna slika" width="185px">
				<div class="editProfilePicture" >
					<button class="icon mt-1" >
						<i><?php echo $__env->yieldContent('editProfilePicture'); ?></i>
					</button>
				</div>
			</div>
			
		</div>
		<div class="col-sm-2">
			<div class="container ml-2">
				<div class="row mt-3">
					<div class="col-sm-12">
						<h1>
							<label><?php echo e($username); ?>

								
							</label>


						</h1>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<h4>
							<label>
								 <?php echo e($rank); ?>

							</label>
						</h4>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<h4>
							<label>
								Lvl <?php echo e($level); ?>

							</label>
						</h4>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
							
					<?php if($grade!=null): ?>
						Ocena: <?php echo e($grade); ?>

					<?php else: ?>
						Ocena: 	Nema ocene
					<?php endif; ?>
					</div>
				</div>

			</div>
		</div>
		<div class="col-sm-2">

		</div>
		<div class="col-sm-2">

		</div>
		<div class="col-sm-2">
			<div class="container ">
				<div class="row mt-2">
					<div class="col-sm-12">
						<?php echo $__env->yieldContent("posaljiPoruku"); ?>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<?php echo $__env->yieldContent('btn5'); ?>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<?php echo $__env->yieldContent('btn6'); ?>
					</div>
				</div>
			</div>
		</div>
		<div class="col-sm-2">
			<div class="container">
				<div class="row mt-2">
					<div class="col-sm-12">
						<a class="clearFormat" data-toggle="modal" href="#changePassword"> 
						<?php echo $__env->yieldContent('promeniLozinku'); ?>
						</a>
						<?php echo $__env->yieldContent('oceniKorisnika'); ?>
						<a class="clearFormat" data-toggle="modal" href="#udaljiSaSajta">
							<?php echo $__env->yieldContent('udaljiSaSajta'); ?>
						</a>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<?php echo $__env->yieldContent('kreirajOglas'); ?>
						<a class="clearFormat" data-toggle="modal" href="#blokirajKor">
						<?php echo $__env->yieldContent('blokiraj'); ?>
						</a>
						<a class="clearFormat"  href="unaprediKor?korisnik=<?php echo e($username); ?>">
							<?php echo $__env->yieldContent('unapredi'); ?>
						</a>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<a class="clearFormat" data-toggle="modal" href="#obrisiNalog"> 
						<?php echo $__env->yieldContent('obrisiNalog'); ?>
						</a>
						<a class="clearFormat"  href="zapratiKor?pracenKorisnik=<?php echo e($username); ?>">
							<?php echo $__env->yieldContent('zaprati'); ?>
						</a>
						<a class="clearFormat" data-toggle="modal" href="#sendMessage">
							<?php echo $__env->yieldContent('posaljiPorukuAdmin'); ?>
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>


	<div class="row mt-1">
	<div class="col-sm-9">
		<div class="row">
	

<?php if($niz1!=null): ?>
	<div class="col-sm-4 mt-3">
			
			<div class="card  align-items-center" style="padding:10px;background-color: rgba(5,5,5,0.6); color:white">
				<div class=" ml-auto">
					<a href="showFormAd?ad=<?php echo e($niz1['id']); ?>">
							<?php echo $__env->yieldContent('icon11'); ?>


							<!--<i class="material-icons" style="cursor:pointer;">create</i>-->
					</a>
					<a data-toggle="modal" href="#deleteModal1">
						<?php echo $__env->yieldContent('icon12'); ?>
					</a> 	
				</div>
				<div class="card-title">
				
					<h2 >
						<label id="pozicija1">
						<?php echo e($niz1['position']); ?>

						</label>
					</h2>


				</div>
				<div class="card-title">
					<h3 >
						<label id="mapa1">
							<?php echo e($niz1['mode']); ?>

						</label>
					</h3>
				</div>

				<div class="card-content  ">
					<img class="round" border="3px" src="<?php echo e($niz1['icon1']); ?>" alt="">
					<?php if($niz1['icon2']!=null): ?> 
					<img class="round" border="3px" src="<?php echo e($niz1['icon2']); ?>" alt="">
					<?php endif; ?>
					<?php if($niz1['icon3']!=null): ?> 
					<img class="round" border="3px" src="<?php echo e($niz1['icon3']); ?>" alt="">
					<?php endif; ?>
			
		
				</div>

				<div class="card-text m-4"  style="color:#9D907D;">
				<?php echo e($niz1['description']); ?> 
					
				</div>

			</div>

	
	</div>
<?php endif; ?>


<?php if($niz2!=null): ?>
	<div class="col-sm-4 mt-3">
			
			<div class="card  align-items-center" style="padding:10px;background-color: rgba(5,5,5,0.6); color:white">
				<div class=" ml-auto">
					<a href="showFormAd?ad=<?php echo e($niz2['id']); ?>">
							<?php echo $__env->yieldContent('icon11'); ?>


							<!--<i class="material-icons" style="cursor:pointer;">create</i>-->
					</a>
					<a data-toggle="modal" href="#deleteModal2">
						<?php echo $__env->yieldContent('icon12'); ?>
					</a> 	
				</div>
				<div class="card-title">
				
					<h2 >
						<label id="pozicija1">
						<?php echo e($niz2['position']); ?>

						</label>
					</h2>


				</div>
				<div class="card-title">
					<h3 >
						<label id="mapa1">
							<?php echo e($niz2['mode']); ?>

						</label>
					</h3>
				</div>

				<div class="card-content  ">
					<img class="round" border="3px" src="<?php echo e($niz2['icon1']); ?>" alt="">
					<?php if($niz2['icon2']!=null): ?> 
					<img class="round" border="3px" src="<?php echo e($niz2['icon2']); ?>" alt="">
					<?php endif; ?>
					<?php if($niz2['icon3']!=null): ?> 
					<img class="round" border="3px" src="<?php echo e($niz2['icon3']); ?>" alt="">
					<?php endif; ?>
			
		
				</div>

				<div class="card-text m-4"  style="color:#9D907D;">
				<?php echo e($niz2['description']); ?> 
					
				</div>

			</div>

	
	</div>
	<?php endif; ?>



	<?php if($niz3!=null): ?>
	<div class="col-sm-4 mt-3">
			
			<div class="card  align-items-center" style="padding:10px;background-color: rgba(5,5,5,0.6); color:white">
				<div class=" ml-auto">
					<a href="showFormAd?ad=<?php echo e($niz3['id']); ?>">
							<?php echo $__env->yieldContent('icon11'); ?>


							<!--<i class="material-icons" style="cursor:pointer;">create</i>-->
					</a>
					<a data-toggle="modal" href="#deleteModal3">
						<?php echo $__env->yieldContent('icon12'); ?>
					</a> 	
				</div>
				<div class="card-title">
				
					<h2 >
						<label id="pozicija1">
						<?php echo e($niz3['position']); ?>

						</label>
					</h2>


				</div>
				<div class="card-title">
					<h3 >
						<label id="mapa1">
							<?php echo e($niz3['mode']); ?>

						</label>
					</h3>
				</div>

				<div class="card-content  ">
					<img class="round" border="3px" src="<?php echo e($niz3['icon1']); ?>" alt="">
					<?php if($niz3['icon2']!=null): ?> 
					<img class="round" border="3px" src="<?php echo e($niz3['icon2']); ?>" alt="">
					<?php endif; ?>
					<?php if($niz3['icon3']!=null): ?> 
					<img class="round" border="3px" src="<?php echo e($niz3['icon3']); ?>" alt="">
					<?php endif; ?>
			
		
				</div>

				<div class="card-text m-4"  style="color:#9D907D;">
				<?php echo e($niz3['description']); ?> 
					
				</div>

			</div>


	</div>
	<?php endif; ?>	
	</div>	
</div>






	<div class="col-sm-3" >
			<div class=" card mt-3 sidebarCards" style="background-color: rgba(5,5,5,0.8)">
				<div class="ml-auto">
					<a data-toggle="modal" href="#editDescription">
						<?php echo $__env->yieldContent('editDescription'); ?>
					</a>
				</div>
				<h4 class="card-title">
					Kada igram Lol:
				</h4>
				<br>
				<label class="card-text" style="color:#9D907D;">
						<?php echo e($descr); ?>

			
				</label>
			</div>

			<div class="card mt-3 sidebarCards"  >
				
  				  <h4 class="card-title ">Ocene i komentari:</h4>
  			
  				 	<div >
  				 	<a class="clearFormat" data-toggle="modal" href="#leaveComment">
					<?php echo $__env->yieldContent("grade"); ?>
				</a>
				</div>
  				<div class="container-fluid">	
  					
  					<?php $i=0;?>
  					<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  					<div class="row ">
  						<div class="card container-fluid " style="padding:15px;background-color: rgba(5,5,5,0.5);">
  							<div class="row">
  								<div class=" mr-2 ml-auto">
  									<a  href="obrisiKom?korisnik=<?php echo e($username); ?>&komentar=<?php echo e($comments[$i]->id); ?>">
										<?php echo $__env->yieldContent('btnSidebar1'); ?>
									</a>
								</div>
							
								
								<div class="col-sm-12 ">
										<img style="margin-bottom:5px; margin-left:-5px; vertical-align:bottom " width="35px" alt="Profilna slika" src="<?php echo e($icons[$i]); ?>">
									<?php echo e($users[$i]); ?>

									
								
							    </div>
							
							</div>
						<div class="row" >
							<div class="card-text ml-2 mr-2"  style="color:#9D907D;">
								
								<?php echo e($comment->content); ?>

							</div>
							</div>
						
						<div class="row d-flex justify-content-end">


							<div class=" flex-col-sm-6">
								Ocena: <?php echo e($comment->grade); ?>

							</div>
						
						</div>
					</div>
					</div>
					<?php $i++;?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  				
  				
			</div>

		
	</div>
</div>

<!-- delete za prvo ad-->
	<div class="modal fade" id="deleteModal1">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content pages ">

	      <!-- Modal Header -->
	      <div class="modal-header ">
	        <h4 class="modal-title d-flex justify-content-center">Da li ste sigurni?</h4>
	        <button type="button" class="close" style="color:white;" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      

	      <!-- Modal footer -->
	      <div class="modal-body">
	      	<div class="row">
	      		<div class="col-sm-6">
	      			<form name="prva" method="post" action="deleteAd">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id" value="

						<?php if($niz1!=null): ?>
						<?php echo e($niz1['id']); ?>

						<?php endif; ?>
						">
		
	      				<button type="submit" class="buttonGrade btn-block	" style="padding:7px;"  >Potvrdi</button>
	      			</form>
	      		</div>
	      		<div class="col-sm-6">
	      			<button type="button" class="buttonGrade btn-block" style="padding:7px;" data-dismiss="modal">Odustani</button>
	      		</div>
	      		
	      	</div>
	        
	        
	      </div>

	    </div>
	  </div>
	</div>


<!-- delete za drugi ad-->
	<div class="modal fade" id="deleteModal2">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content pages ">

	      <!-- Modal Header -->
	      <div class="modal-header ">
	        <h4 class="modal-title d-flex justify-content-center">Da li ste sigurni?</h4>
	        <button type="button" class="close" style="color:white;" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      

	      <!-- Modal footer -->
	      <div class="modal-body">
	      	<div class="row">
	      		<div class="col-sm-6">
	      			<form name="druga" method="post" action="deleteAd">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id" value="

						<?php if($niz2!=null): ?>
						<?php echo e($niz2['id']); ?>

						<?php endif; ?>
						">
		
	      				<button type="submit" class="buttonGrade btn-block	" style="padding:7px;"  >Potvrdi</button>
	      			</form>
	      		</div>
	      		<div class="col-sm-6">
	      			<button type="button" class="buttonGrade btn-block" style="padding:7px;" data-dismiss="modal">Odustani</button>
	      		</div>
	      		
	      	</div>
	        
	        
	      </div>

	    </div>
	  </div>
	</div>


<!-- delete za treci ad-->
	<div class="modal fade" id="deleteModal3">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content pages ">

	      <!-- Modal Header -->
	      <div class="modal-header ">
	        <h4 class="modal-title d-flex justify-content-center">Da li ste sigurni?</h4>
	        <button type="button" class="close" style="color:white;" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      

	      <!-- Modal footer -->
	      <div class="modal-body">
	      	<div class="row">
	      		<div class="col-sm-6">
	      			<form name="treca" method="post" action="deleteAd">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id" value="
						<?php if($niz3!=null): ?>
						<?php echo e($niz3['id']); ?>">
						<?php endif; ?>
		
	      				<button type="submit" class="buttonGrade btn-block	" style="padding:7px;"  >Potvrdi</button>
	      			</form>
	      		</div>
	      		<div class="col-sm-6">
	      			<button type="button" class="buttonGrade btn-block" style="padding:7px;" data-dismiss="modal">Odustani</button>
	      		</div>
	      		
	      	</div>
	        
	        
	      </div>

	    </div>
	  </div>
	</div>

<!-- za bokiranje-->
<div class="modal fade" id="blokirajKor">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content pages ">

	      <!-- Modal Header -->
	      <div class="modal-header ">
	        <h4 class="modal-title d-flex justify-content-center">Da li ste sigurni?</h4>
	        <button type="button" class="close" style="color:white;" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      

	      <!-- Modal footer -->
	      <div class="modal-body">
	      	<div class="row">
	      		<div class="col-sm-6">
	      			<form name="prva" method="post" action="blokirajKorisnika">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="username" value="
						<?php echo e($username); ?>

						">
		
	      				<button type="submit" class="buttonGrade btn-block	" style="padding:7px;"  >Potvrdi</button>
	      			</form>
	      		</div>
	      		<div class="col-sm-6">
	      			<button type="button" class="buttonGrade btn-block" style="padding:7px;" data-dismiss="modal">Odustani</button>
	      		</div>
	      		
	      	</div>
	        
	        
	      </div>

	    </div>
	  </div>
	</div>


<!-- Banovanje sa sajta-->

<div class="modal fade" id="udaljiSaSajta">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content pages ">

	      <!-- Modal Header -->
	      <div class="modal-header ">
	        <h4 class="modal-title d-flex justify-content-center">Da li ste sigurni?</h4>
	        <button type="button" class="close" style="color:white;" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      

	      <!-- Modal footer -->
	      <div class="modal-body">
	      	<div class="row">
	      		<div class="col-sm-6">
	      			<form name="prva" method="post" action="udaljiSaSajta">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="username" value="
						<?php echo e($username); ?>

						">
		
	      				<button type="submit" class="buttonGrade btn-block	" style="padding:7px;"  >Potvrdi</button>
	      			</form>
	      		</div>
	      		<div class="col-sm-6">
	      			<button type="button" class="buttonGrade btn-block" style="padding:7px;" data-dismiss="modal">Odustani</button>
	      		</div>
	      		
	      	</div>
	        
	        
	      </div>

	    </div>
	  </div>
	</div>
<!-- Brisanj enaloga-->

<div class="modal fade" id="obrisiNalog">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content pages ">

	      <!-- Modal Header -->
	      <div class="modal-header ">
	        <h4 class="modal-title d-flex justify-content-center">Da li ste sigurni?</h4>
	        <button type="button" class="close" style="color:white;" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      

	      <!-- Modal footer -->
	      <div class="modal-body">
	      	<div class="row">
	      		<div class="col-sm-6">
	      			<form name="prva" method="post" action="obrisiNalog">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="username" value="
						<?php echo e($username); ?>

						">
		
	      				<button type="submit" class="buttonGrade btn-block	" style="padding:7px;"  >Potvrdi</button>
	      			</form>
	      		</div>
	      		<div class="col-sm-6">
	      			<button type="button" class="buttonGrade btn-block" style="padding:7px;" data-dismiss="modal">Odustani</button>
	      		</div>
	      		
	      	</div>
	        
	        
	      </div>

	    </div>
	  </div>
	</div>



<div class="modal fade" id="changePassword">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content pages ">

	      <!-- Modal Header -->
	      <div class="modal-header ">
	        <h4 class="modal-title d-flex justify-content-center" >Promeni lozinku</h4>
	        <button type="button" class="close" style="color:white;" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      <?php if(count($errors)>0): ?>
	      	<?php if($errors->has('staraLozinka') || $errors->has('novaLozinka') || $errors->has('ponoviLozinku')): ?>
	         		<div class="alert-danger">
	         			<ul>
	         					<?php $__currentLoopData = $errors->get('novaLozinka'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	         					<li><?php echo e($message); ?> 	</li>
	         					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	         					<?php $__currentLoopData = $errors->get('staraLozinka'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	         					<li><?php echo e($message); ?> 	</li>
	         					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	         					<?php $__currentLoopData = $errors->get('ponoviLozinku'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	         					<li><?php echo e($message); ?> 	</li>
	         					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	         			
	         			</ul>
	         		</div>
	         		<?php endif; ?>
	         	<?php endif; ?>

	      <!-- Modal footer -->
	      <div class="modal-body">
	      	<div class="container">
	      		
	      		<form action="changePassword" method="post" class="m-3">
	      			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	      			<div class="form-group">
	      				<div class="row">
	      					<div class="col-sm-6">
	      						<label style="color:#9D907D;">	Stara lozinka:</label>
	      					</div>
	      					<div class="col-sm-6">
	      						<input name="staraLozinka" type="password" >
	      					</div>
	      				</div>
	      			</div>
	      			<div class="form-group">
	      				<div class="row">
	      					<div class="col-sm-6">
	      						<label style="color:#9D907D;">	Nova lozinka:</label>
	      					</div>
	      					<div class="col-sm-6">
	      						<input name="novaLozinka" type="password" >
	      					</div>
	      				</div>
	      			</div>
	      			<div class="form-group">
	      				<div class="row">
	      					<div class="col-sm-6">
	      						<label style="color:#9D907D;">	Ponovi lozinku:</label>
	      					</div>
	      					<div class="col-sm-6">
	      						<input name="ponoviLozinku" type="password" >
	      					</div>
	      				</div>
	      			</div>
				<div class="row">
	      		<div class="col-sm-6">
	      			<button type="submit" class="buttonGrade btn-block	"  style="padding:7px;" >Potvrdi</button>
	      		</div>
	      		<div class="col-sm-6">
	      			<button type="button" class="buttonGrade btn-block" style="padding:7px;" data-dismiss="modal">Odustani</button>
	      		</div>
	      		
	      	</div>

	      		
	      		</form>	
	      	</div>
	      	
	        
	        
	      </div>

	    </div>
	  </div>
	</div>




<div class="modal fade" id="editDescription">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content pages ">

	      <!-- Modal Header -->
	      <div class="modal-header ">
	        <h4 class="modal-title d-flex justify-content-center" >Kada igram Lol</h4>
	        <button type="button" class="close" style="color:white;" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      
 				 <?php if(count($errors)>0): ?>
			 		 <?php if($errors->has('description')): ?>
	         			<div class="alert-danger">
	         				<ul>
	         					<?php $__currentLoopData = $errors->get('description'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	         					<li><?php echo e($message); ?> 	</li>
	         					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	         				</ul>
	         			</div>
	         		<?php endif; ?>
	         	<?php endif; ?>

	      <!-- Modal footer -->
	      <div class="modal-body">
	      	<div class="container">
	      		
	      		<form class="m-3" action='editDescription' method='post' >
	      			<div class="form-group">
	      			 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">		
	      					
	      				
	      				<div class="row">
	      					<div class="col-sm-12">
	      					<textarea name="description" style="border:  2px solid #184157; "type="text" class="form-control"  placeholder="Šta tražiš od saigrača"></textarea>
	      					</div>
	      				</div>
	      			</div>
	      			
	      				<div class="row">
	      		<div class="col-sm-6">
	      			<button name="dugme" type="submit" class="buttonGrade btn-block	" style="padding:7px;"  >Potvrdi</button>
	      		</div>
	      		<div class="col-sm-6">
	      			<button type="button" name="odustani" class="buttonGrade btn-block" style="padding:7px;" data-dismiss="modal">Odustani</button>
	      		</div>
	      		
	      	</div>

	      		
	      		</form>	
	      	</div>
	      	
	        
	        
	      </div>

	    </div>
	  </div>
	</div>



<!-- Slanje poruke-->
<div class="modal fade" id="sendMessage">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content pages ">

	      <!-- Modal Header -->
	      <div class="modal-header ">
	        <h4 class="modal-title d-flex justify-content-center" >Pošalji poruku : <?php echo e($username); ?></h4>
	        <button type="button" class="close" style="color:white;" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      

	      <!-- Modal footer -->
	      <div class="modal-body">
	      	<div class="container">
	      		
	      		<form class="m-3" method="post" action="slanjePoruke">


 	 <?php if(count($errors)>0): ?>
	      	<?php if($errors->has('poruka') ): ?>
	         		<div class="alert-danger">
	         			<ul>
	         					<?php $__currentLoopData = $errors->get('poruka'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	         					<li><?php echo e($message); ?> 	</li>
	         					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	         					

	         			
	         			</ul>
	         		</div>
	         		<?php endif; ?>
	         	<?php endif; ?>


	      				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="username" value="
						<?php echo e($username); ?>

						">
	      			<div class="form-group">
	      				
	      				<div class="row">
	      					<div class="col-sm-12">
	      					<textarea name="poruka" style="border:  2px solid #184157; "type="text" class="form-control"  placeholder="Šta tražiš od saigrača"></textarea>
	      					</div>
	      				</div>
	      			</div>
	      			
	      				<div class="row">
	      		<div class="col-sm-6">
	      			<button type="submit" class="buttonGrade btn-block	" style="padding:7px;">Pošalji</button>
	      		</div>
	      		<div class="col-sm-6">
	      			<button type="button" class="buttonGrade btn-block" style="padding:7px;" data-dismiss="modal">Odustani</button>
	      		</div>
	      		
	      	</div>

	      		
	      		</form>	
	      	</div>
	      	
	        
	        
	      </div>

	    </div>
	  </div>
	</div>



<div class="modal fade" id="leaveComment">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content pages ">

	      <!-- Modal Header -->
	      <div class="modal-header ">
	        <h4 class="modal-title d-flex justify-content-center" >Oceni korisnika</h4>
	        <button type="button" class="close" style="color:white;" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      

	      <!-- Modal footer -->
	      <div class="modal-body">
	      	<div class="container">
	      		
	      		<form class="m-3" method="post" action="oceniKorisnika">

	      				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="username" value="
						<?php echo e($username); ?>

						">
	      			<div class="form-group">
	      				<div class="row">
	      					<div class="col-sm-12">
	      						<label style="color:#9D907D;" >
	      							Ostavi komentar:
	      						</label>
	      					</div>
	      				</div>
	      				<div class="row">
	      					<div class="col-sm-12">
	      					<textarea name="komentar" style="border:  2px solid #184157; "type="text" class="form-control"  placeholder="Šta tražiš od saigrača"></textarea>
	      					</div>
	      				</div>
	      				<div class="row mt-3">
	      					<div class="col-sm-6">
	      						<label style="color:#9D907D;" >
	      							Ostavi ocenu:
	      						</label>
	      					</div>
	      				<div class="col-sm-6 ml-auto ">
							<input type="radio" name="ocena" checked value="1">1 &nbsp;
							<input type="radio" name="ocena"  value="2">2 &nbsp;
							<input type="radio" name="ocena"  value="3">3 &nbsp;
							<input type="radio" name="ocena"  value="4">4 &nbsp;
							<input type="radio" name="ocena"  value="5">5 &nbsp;
	      				</div>
	      				
	      			</div>
	      			
	      				<div class="row">
	      		<div class="col-sm-6">
	      			<button type="submit" class="buttonGrade btn-block	" style="padding:7px;" >Postavi</button>
	      		</div>
	      		<div class="col-sm-6">
	      			<button type="button" class="buttonGrade btn-block" style="padding:7px;" data-dismiss="modal">Odustani</button>
	      		</div>
	      		
	      	</div>

	      		
	      		</form>	
	      	</div>
	      	
	        
	        
	      </div>

	    </div>
	  </div>
	</div>





</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>