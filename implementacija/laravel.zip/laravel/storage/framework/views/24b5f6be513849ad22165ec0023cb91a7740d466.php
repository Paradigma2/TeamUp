<!--autor: Jana Kragovic 23/2015-->

	
<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/styleprofile.css')); ?>">

<?php $__env->stopSection(); ?>



<?php $__env->startSection('navbar'); ?>
	<?php if(Auth::user()->isMod): ?>
		<?php echo $__env->make('navbar/navbarModerator', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php else: ?>
		<?php echo $__env->make('navbar/navbarUser', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php if(Auth::user()->isAdmin): ?>
<?php $__env->startSection("btnSidebar1"); ?>
		<i class="material-icons" style="cursor:pointer;">delete</i>
<?php $__env->stopSection(); ?>
<?php endif; ?>





<?php $__env->startSection('promeniLozinku'); ?>
	<button  class="button" >Promeni lozinku</button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('kreirajOglas'); ?>
	<a class="clearFormat" href="createEditAdForm"><button  class="button">Kreiraj oglas</button></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('obrisiNalog'); ?>
	<button  class="button" type="button" > Obriši nalog </button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("editDescription"); ?>
	<i class="material-icons" style="cursor:pointer;">create</i>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection("icon11"); ?>
	<i class="material-icons" style="cursor:pointer;">create</i>	
<?php $__env->stopSection(); ?>
<?php $__env->startSection("icon12"); ?>
	<i class="material-icons" style="cursor:pointer;">delete</i>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection("icon21"); ?>
	<i class="material-icons" style="cursor:pointer;">create</i>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection("icon22"); ?>
	<i class="material-icons" style="cursor:pointer;">delete</i>	
<?php $__env->stopSection(); ?>


<?php $__env->startSection("icon31"); ?>
	<i class="material-icons" style="cursor:pointer;">create</i>	
<?php $__env->stopSection(); ?>




<?php $__env->startSection("icon32"); ?>
	<i class="material-icons" style="cursor:pointer;">delete</i>	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile/profile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>