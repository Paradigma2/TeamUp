<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $u; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<h1><?php echo e($a->Username); ?></h1>
	<h2><?php echo e($a->LoLNick); ?></h2>
	<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>