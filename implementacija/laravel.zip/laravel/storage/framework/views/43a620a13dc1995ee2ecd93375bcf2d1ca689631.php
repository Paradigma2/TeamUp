<!--autor: Sanja Perisic 97/2015-->


<?php $__env->startSection('levo1'); ?>
<b>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('desno1'); ?>
</b>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/stylelobby.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/styleprofile.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
	<?php echo $__env->make('navbar/navbarAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row mt-3">
			
			<div class="col-sm-8">
				<div id="demo" class="carousel slide mt-3" data-ride="carousel">
				  <ul class="carousel-indicators">
				    <li data-target="#demo" data-slide-to="0" class="active"></li>
				    <li data-target="#demo" data-slide-to="1"></li>
				    <li data-target="#demo" data-slide-to="2"></li>
				  </ul>
				  <div class="carousel-inner">
				    <div class="carousel-item active">
				    	<a href="#page1">
				      <img src=<?php echo e(URL::asset('slike/carousel1.jpg')); ?> alt="pic1" width="1100" height="300"></a>
				      <div class="carousel-caption">
				        <h6 class="display-4"><label>
				        	<?php if($length>0): ?>
				        	<?php echo e($articles[0]->headline); ?>

				        	<?php endif; ?>
				        </label></h6>
				      </div>   
				    </div>
				    <div class="carousel-item">
				    	<a href="#page1">
				      <img src=<?php echo e(URL::asset('slike/carousel2.jpg')); ?> alt="pic2" width="1100" height="300"></a>
				      <div class="carousel-caption">
				        <h1 class="display-4"><label><?php if($length>1): ?>
				        	<?php echo e($articles[1]->headline); ?>

				        	<?php endif; ?></label></h1>
				      </div>   
				    </div>
				    <div class="carousel-item">
				    	<a href="#page2">
				      <img src=<?php echo e(URL::asset('slike/carousel3.jpg')); ?> alt="pic3" width="1100" height="300"></a>
				      <div class="carousel-caption">
				        <h1 class="display-4"><label><?php if($length>2): ?>
				        	<?php echo e($articles[2]->headline); ?>

				        	<?php endif; ?></label></h1>
				      </div>   
				    </div>
				    
				  </div>
				  <a class="carousel-control-prev" href="#demo" data-slide="prev">
				    <span class="carousel-control-prev-icon"></span>
				  </a>
				  <a class="carousel-control-next" href="#demo" data-slide="next">
				    <span class="carousel-control-next-icon"></span>
				  </a>
				</div>

				<div class="row">
					
					<div class="col-sm-12 mt-3 tab-content">
						<label hidden><?php echo e($l = $length); ?></label>
						<?php for($j=0, $page=0; $j<$l; $page++): ?>
						<?php if($j==0): ?>
							<div class="tab-pane active" id="page<?php echo e($page + 1); ?>">
						<?php else: ?>
							<div class="tab-pane fade" id="page<?php echo e($page + 1); ?>">
						<?php endif; ?>

						<?php for($i=0; $i<3 && $j<$l; $i++, $j++): ?>
							<div class="row">
								<div class="col-sm-12">
									<div class="card mt-2 article">
										
										<div class="card-body">
											<div class="row">
												<div class="col-sm-11">
													<h4 class="card-title headline mt-1" >
														<label><?php echo e($articles[$j]->headline); ?></label>
													</h4>
												</div>
												<div class="col-sm-1">
													<a data-toggle="modal" href="#deleteModal<?php echo e($articles[$j]->id); ?>">
														<i class="material-icons" style="cursor:pointer;">delete</i>
													</a>
													
												</div>
											</div>
											<?php
												$content = $articles[$j]->content;
												$splitContent = explode(PHP_EOL, $content);
											?>
											<p class="card-text"><?php echo e($splitContent[0]); ?></p>


											<div class="card-text collapse" id="collapseArticle<?php echo e($articles[$j]->id); ?>">
												<?php $__currentLoopData = $splitContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($c != $splitContent[0]): ?>
													<p><?php echo e($c); ?></p>
													<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</div>
											<div class="row">
								<div class="col-sm-2">
								<a data-toggle="collapse" href="#collapseArticle<?php echo e($articles[$j]->id); ?>" onclick="proba('klik<?php echo e($articles[$j]->id); ?>')" >
									<i class="material-icons" > <label style="cursor:pointer;" id="klik<?php echo e($articles[$j]->id); ?>">expand_more</label></i>
								</a>
								</div>
								<div class="col-sm-10 headline" style="text-align:right;">
									<img src="/<?php echo e($authors[$j]->icon); ?>" width="15px">
									<strong><?php echo e($authors[$j]->username); ?></strong>,
									<?php echo e($articles[$j]->updated_at); ?>

									
								</div>
								</div>
										</div>
									</div>
								</div>
							</div>

							
						<?php endfor; ?>
						</div>
						<?php endfor; ?>
					
								
								<ul class="pagination nav nav-pills mt-3 d-flex justify-content-center">
								<?php for($i=0; $i<$page; $i++): ?>
								<li class="page-item"><a class="page-link" data-toggle="pill" href="#page<?php echo e($i + 1); ?>"><?php echo e($i + 1); ?></a></li>
								<?php endfor; ?>
								</ul>
								
					</div>

			</div>
			
		</div>
		<div class="col-sm-4">
				<div class="card mt-3 article">
					<div class="card-body">
						<div class="card-title">
							<h2>Pretrazi</h2>
							
						</div>
						<div class="row">
							<div class="col-sm-12 mb-3">
								<form name="searchUserForm" method="GET" action="searchUserByName">
									<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
									<div class="row">
									<div class="col-sm-8">
										<input type="text" class="form-control form-control-sm" name="usernameSearch" id="usernameSearch" style="font-size=8pt;" value="<?php echo e($p); ?>">
									</div>
									<div class="col-sm-4">
										<button id="searchBt" type="submit" class="btn btn-primary btn-sm">Trazi</button>
									</div>
									</div>
								</form>
							</div>
						</div>
						<?php 
							$length = count($users);
						 ?>
						<!--      sredi ovooo   -->
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<p><?php echo e($error); ?></p>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php if($length > 0 && ($users[0] == "Ne postoji korisnik")): ?>
							<p><?php echo e($users[0]); ?></p>
						<?php elseif($length>0): ?>
						<div class="list-group pages" style="height:150px; overflow-y:auto;">
						  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($theUser->id == $u->id): ?>
							<a href="/showUser" class="list-group-item list-group-item-action pages list-group-item-dark"><img src="/<?php echo e($u->icon); ?>" width="30px" class="mr-2"><?php echo e($u->username); ?></a>
							<?php else: ?>
							<a href="/another?id=<?php echo e($u->id); ?>" class="list-group-item list-group-item-action pages list-group-item-dark"><img src="/<?php echo e($u->icon); ?>" width="30px" class="mr-2"><?php echo e($u->username); ?></a>
							<?php endif; ?>
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						 </div>
						 <?php endif; ?>
						
					</div>
					
				</div>
			</div>
		
	</div>
	<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="modal fade" id="deleteModal<?php echo e($article->id); ?>">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content pages">

	      <!-- Modal Header -->
	      <div class="modal-header ">
	        <h4 class="modal-title d-flex justify-content-center">Da li ste sigurni?</h4>
	        <button type="button" class="close" style="color:white;" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      

	      <!-- Modal footer -->
	      <div class="modal-body">
	      	<div class="row">
	      		<div class="col-sm-12  d-flex justify-content-center">
	      			<form name="deleteArticleAdmin" action="deleteArticleAdmin" method="POST">
	      				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	      				<input type="hidden" name="id" value="<?php echo e($article->id); ?>">
	      			<button type="submit" class="btn btn-primary mr-2" >Potvrdi</button>
	      			</form>
	      			<button type="button" class="btn btn-primary" data-dismiss="modal">Odustani</button>
	      		</div>
	      		
	      	</div>
	        
	        
	      </div>

	    </div>
	  </div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<script language="javascript">
		function proba(klik){
			labela = document.getElementById(klik);
			if(labela.innerHTML == "expand_more"){
				labela.innerHTML="expand_less"
			}
			else{
				labela.innerHTML="expand_more"
			}
		}
	</script>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>