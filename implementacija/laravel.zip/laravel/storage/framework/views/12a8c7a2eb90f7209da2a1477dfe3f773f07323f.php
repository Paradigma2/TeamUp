<!--autor: Jana Kragovic 23/2015-->

	
<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/styleprofile.css')); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('navbar'); ?>
	<?php if(Auth::user()->isMod): ?>
		<?php echo $__env->make('navbar/navbarModerator', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php else: ?>
		<?php echo $__env->make('navbar/navbarUser', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('grade'); ?>
	<button class="mt-2 mb-2 buttonGrade btn-block" >
		Oceni korisnika
	</button>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('blokiraj'); ?>
	<?php if($isAdmin==0): ?>
	<button  class="button"  href="">Blokiraj</button>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('zaprati'); ?>
	<?php if($prati==0): ?>
	<button  class="button" href="">Zaprati</button>
	<?php else: ?>
		<button  class="button" href="">Prekini praćenje</button>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('posaljiPorukuAdmin'); ?>
	<button id="obrisi" class="button" href="">Pošalji poruku</button>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile/profile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>