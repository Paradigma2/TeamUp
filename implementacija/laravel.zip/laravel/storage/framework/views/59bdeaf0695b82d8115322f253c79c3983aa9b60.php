<!--autor: Jana Kragovic 23/2015-->

		<div  >
			<nav  class="navbar navbar-expand-sm navbar-dark mt-3">
			
					
				<!-- Brand/logo -->
				<a class="navbar-brand" href="#">TeamUp!</a>

				 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
   					 <span class="navbar-toggler-icon"></span>
  				</button>
				<!-- Linkovi levo-->
				<div class="collapse navbar-collapse" id="collapsibleNavbar">
				<ul class="navbar-nav">
					<li class="nav-item">
						<?php echo $__env->yieldContent('levo1'); ?>
						<?php echo $__env->yieldContent('link1'); ?>
						<?php echo $__env->yieldContent('desno1'); ?>
					</li>
					<li class="nav-item">
						<?php echo $__env->yieldContent('levo2'); ?>
						<?php echo $__env->yieldContent('link2'); ?>
						<?php echo $__env->yieldContent('desno2'); ?>
					</li>
					<li class="nav-item">
						<?php echo $__env->yieldContent('levo3'); ?>
						<?php echo $__env->yieldContent('link3'); ?>
						<?php echo $__env->yieldContent('desno3'); ?>
					</li>

				</ul>

				<!-- linkovi desno-->

				<ul  class="navbar-nav   ml-auto" style="margin-right: 80px;"	>
					
					<li class=" nav-item">	
							<?php echo $__env->yieldContent('levo5'); ?>
						<?php echo $__env->yieldContent('link5'); ?>
							<?php echo $__env->yieldContent('desno5'); ?>
					</li>
					<li   class=" nav-item">
							<?php echo $__env->yieldContent('levo4'); ?>
						
								<?php echo $__env->yieldContent('link4'); ?>
						
							<?php echo $__env->yieldContent('desno4'); ?>
					</li>
				</ul>
				</div>

			</nav>
		</div>
