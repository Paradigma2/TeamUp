@extends('navbar/navbar')



@section('link1')
	<a class="nav-link"  href="#">Lobi</a>
@endsection



@section('link2')
	<a class="nav-link"  href="#">Nađi saigrača</a>
@endsection


@section('link5')
	 



@endsection