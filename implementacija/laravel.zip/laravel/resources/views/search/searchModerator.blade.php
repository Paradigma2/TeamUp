@extends('search/search')

@section('navbar')
	@include('navbar/navbarModerator')
@endsection