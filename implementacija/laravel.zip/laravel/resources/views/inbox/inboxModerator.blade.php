@extends('inbox/inbox')
	
@section('styles')
	<link rel="stylesheet" href="{{ URL::asset('css/styleInbox.css') }}">

@endsection


@section('navbar')


	@include('navbar/navbarModerator')


@endsection

