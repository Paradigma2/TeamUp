@extends('main')

@section('styles')
	<link rel="stylesheet" href="{{ URL::asset('css/styleProfile.css') }}">
@endsection
@section('navbar')


	@include('navbar/navbarAdmin')


@endsection

@section('content')

	

@endsection